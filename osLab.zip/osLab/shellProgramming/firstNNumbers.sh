i=1
echo "Enter the limit:"
read n
echo "The first $n natural numbers are:"
while [ $i -le $n ]
do
echo "$i"
i=$(expr $i + 1)
done
