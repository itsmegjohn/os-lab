echo "Enter the Number:"
read n
c=$(expr $n%2)
if [ $c -eq 0 ]
then
echo "Even"
else
echo "Odd"
fi
