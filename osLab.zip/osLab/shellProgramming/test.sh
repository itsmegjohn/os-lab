echo "Enter your name:"
read name
echo "Enter your semester:"
read sem

echo "Name: $name"
echo "Semester: $sem"

